from django.db import models
from cursos.models import Cursos

class Conteudo(models.Model):
    titulo = models.CharField(max_length=250)
    descricao = models.TextField()
    id_curso = models.ForeignKey(Cursos, on_delete=models.CASCADE)

    def __str__(self):
        return self.titulo