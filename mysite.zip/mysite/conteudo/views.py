from multiprocessing import context
from django.views.generic import DetailView, ListView
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, reverse, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db import models
from conteudo.forms import ConteudoForm

from conteudo.models import Conteudo
from cursos.models import Cursos

#view de listagem de cursos
@login_required(login_url ='/register/login/')
def listar(request, id_curso):
    #recupero todos os cursos que estão na base de dados
    Curso = get_object_or_404(Cursos, pk = id_curso)
    conteudo = Conteudo.objects.filter(id_curso = Curso)

    #defino quais as variáveis irão ser passadas pelo contexto
    context = {
        'conteudo': conteudo,
    }
    #renderizando o template para o usuário e passando as variáveis do contexto.
    return render(request, 'conteudo/listar.html', context)

#view de exclusão de cucursorso
@login_required(login_url ='/register/login/')
def excluir(request, id_conteudo):
    Conteudo.objects.get(pk=id_conteudo).delete()
    return HttpResponseRedirect("/cursos/")

@login_required(login_url ='/register/login/')
def criar(request):
    
    if request.method == "POST":
        form = ConteudoForm(request.POST)
        
        if form.is_valid():
            form.save()
            return HttpResponseRedirect("/cursos/")
    else:
        form = ConteudoForm()
    
    context = {
        'form': form
    }
    return render(request,'conteudo/criar.html', context)

@login_required(login_url ='/register/login/')
def editar(request, id_conteudo):
    
    conteudo = Conteudo.objects.get(pk=id_conteudo)
    
    if request.method == "POST":
        form = ConteudoForm(request.POST, instance=conteudo)
        
        if form.is_valid():
            form.save()
            return HttpResponseRedirect("/cursos/")
    else:
        form = ConteudoForm(instance=conteudo)
    
    context = {
        'form': form,
        'id_conteudo': id_conteudo
    }
    
    
    return render(request, 'conteudo/editar.html', context)





