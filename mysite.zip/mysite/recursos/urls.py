from django.urls import path
from . import views

urlpatterns = [
    path('listar/<int:id_conteudo>/', views.listar, name="listar"),
    path('excluir/<int:id_recursos>/', views.excluir, name="excluir"),
    path('criar/', views.criar, name='criar'),
    path('editar/<int:id_recursos>/', views.editar, name='editar'),
]