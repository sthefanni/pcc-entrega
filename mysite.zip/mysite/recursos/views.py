from multiprocessing import context
from django.views.generic import DetailView, ListView
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, reverse, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db import models
from recursos.forms import RecursosForm

from recursos.models import Recursos
from conteudo.models import Conteudo
#view de listagem de cursos
@login_required(login_url ='/register/login/')
def listar(request, id_conteudo):
    #recupero todos os cursos que estão na base de dados
    conteudo =  get_object_or_404(Conteudo, pk = id_conteudo)
    recursos = Recursos.objects.filter(id_conteudo = conteudo)

    #defino quais as variáveis irão ser passadas pelo contexto
    context = {
        'recursos': recursos,
    }
    #renderizando o template para o usuário e passando as variáveis do contexto.
    return render(request, 'recursos/listar.html', context)

@login_required(login_url ='/register/login/')
#view de exclusão de cucursorso
def excluir(request, id_recursos):
    Recursos.objects.get(pk=id_recursos).delete()
    return HttpResponseRedirect("/cursos/")

@login_required(login_url ='/register/login/')
def criar(request):
    
    if request.method == "POST":
        form = RecursosForm(request.POST)
        
        if form.is_valid():
            form.save()
            return HttpResponseRedirect("/cursos/")
    else:
        form = RecursosForm()
    
    context = {
        'form': form
    }
    return render(request,'recursos/criar.html', context)

@login_required(login_url ='/register/login/')
def editar(request, id_recursos):
    
    recursos = Recursos.objects.get(pk=id_recursos)
    
    if request.method == "POST":
        form = RecursosForm(request.POST, instance=recursos)
        
        if form.is_valid():
            form.save()
            return HttpResponseRedirect("/cursos/")
    else:
        form = RecursosForm(instance=recursos)
    
    context = {
        'form': form,
        'id_recursos': id_recursos
    }
    
    return render(request, 'recursos/editar.html', context)



