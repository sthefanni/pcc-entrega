from django.contrib import admin

from .models import Recursos

admin.site.register(Recursos)