from django.contrib import admin

from .models import Cursos

admin.site.register(Cursos)